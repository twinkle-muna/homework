var express = require('express');
var router = express.Router();
var fs=require("fs");

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get("/infoAnimal", function(req,res){
  fs.appendFileSync("animal.txt", req.query.anim+" "+req.query.height+" "+req.query.weight+ " ");

  res.render("animal.hbs", {})
});

router.get("/getAnimal", function(req,res){
  let textFromTxt=fs.readFileSync("animal.txt", "utf8");
  console.log(textFromTxt);
  res.render("animalList.hbs", {
    animal:textFromTxt
  })
});

module.exports = router;
